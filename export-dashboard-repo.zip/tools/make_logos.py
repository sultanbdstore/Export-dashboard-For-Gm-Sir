"""Cut the person out of the source logo and rebuild icons on a clean background (no dot, ear intact).
Usage: python3 make_logos2.py <source-512.png> <out-dir>"""
import sys, numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

SRC, OUT = sys.argv[1], sys.argv[2]
FONT = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
src = Image.open(SRC).convert("RGBA"); a = np.array(src); H, W = a.shape[:2]
rgb = a[..., :3]
yy, xx = np.mgrid[:H, :W]; rad = np.hypot(xx - W/2 + .5, yy - H/2 + .5)

# --- person mask: everything inside the ring that is not the navy backdrop
hsv = cv2.cvtColor(rgb.astype(np.float32)/255, cv2.COLOR_RGB2HSV)
h, s, v = hsv[..., 0]/360, hsv[..., 1], hsv[..., 2]
navy = (s > 0.55) & (v < 0.6) & (h > 0.55) & (h < 0.70)
green = (h > 0.35) & (h < 0.5) & (s > 0.6) & (v > 0.5)          # old S + ring
blue_bright = (h > 0.55) & (h < 0.68) & (s > 0.5) & (v >= 0.6)  # dot
P = (~navy) & (~green) & (~blue_bright) & (rad < 236)
P = cv2.morphologyEx(P.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
n, lab, st, _ = cv2.connectedComponentsWithStats(P, connectivity=4)
big = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA]); P = (lab == big).astype(np.uint8)
# suit is dark and reads as backdrop: fill each row below the shoulders between its extremes
for y in range(350, H):
    xs_ = np.where(P[y] > 0)[0]
    if y >= 376: P[y, rad[y] < 236] = 1
    elif len(xs_) > 20: P[y, xs_.min():xs_.max()+1] = 1
# fill holes
ff = P.copy() * 255; m = np.zeros((H+2, W+2), np.uint8)
cv2.floodFill(ff, m, (0, 0), 128); P = ((ff != 128)).astype(np.uint8)
P = cv2.erode(P, np.ones((3, 3), np.uint8), iterations=1)
alpha = cv2.GaussianBlur(P.astype(np.float32), (0, 0), 1.0)
Image.fromarray((alpha*255).astype(np.uint8)).save("/home/claude/work/mask_debug.png")

person = np.dstack([rgb, (alpha*255).astype(np.uint8)])
person = Image.fromarray(person, "RGBA")
ring_img = src.copy()  # original ring (outside r>=236 kept)

def radial_bg(c_in, c_out, size=512, cx=.5, cy=.4):
    y, x = np.mgrid[:size, :size] / size
    d = np.clip(np.hypot(x-cx, y-cy)/0.75, 0, 1)[..., None]
    arr = np.array(c_in)*(1-d) + np.array(c_out)*d
    return Image.fromarray(arr.astype(np.uint8), "RGB").convert("RGBA")

def circle_mask(size, r):
    m = Image.new("L", (size*4, size*4), 0)
    ImageDraw.Draw(m).ellipse([(size*2-r*4), (size*2-r*4), (size*2+r*4), (size*2+r*4)], fill=255)
    return m.resize((size, size), Image.LANCZOS)

def with_ring(base):
    """paste original gradient ring over base (keep r>=236 pixels from source)"""
    ring = ring_img.copy()
    ra = np.array(ring); ra[..., 3] = np.where(rad >= 236, ra[..., 3], 0)
    # soften inner edge
    edge = np.clip((rad - 234)/3, 0, 1); ra[..., 3] = (ra[..., 3]*edge).astype(np.uint8)
    base.alpha_composite(Image.fromarray(ra, "RGBA")); return base

def text_center(img, txt, size, cy, fill, cx=256, spacing=0):
    d = ImageDraw.Draw(img); f = ImageFont.truetype(FONT, size)
    w = d.textlength(txt, font=f) + spacing*(len(txt)-1)
    x = cx - w/2
    for ch in txt:
        d.text((x, cy), ch, font=f, fill=fill, anchor="lm"); x += d.textlength(ch, font=f) + spacing

def finish(img, name, maskable_bg):
    img.save(f"{OUT}/{name}.png")
    return img

def save_set(art, prefix, mk_bg):
    art.save(f"{OUT}/{prefix}logo-512.png")
    art.resize((192, 192), Image.LANCZOS).save(f"{OUT}/{prefix}logo-192.png")
    mk = Image.new("RGBA", (512, 512), mk_bg + (255,))
    sm = art.resize((int(512*.72),)*2, Image.LANCZOS)
    mk.alpha_composite(sm, ((512-sm.width)//2, (512-sm.height)//2)); mk.save(f"{OUT}/{prefix}logo-512-maskable.png")
    return mk_bg

# ===== Design A: same style, violet background, photo only (ear intact, no dot), name below
A = radial_bg((74, 28, 140), (14, 8, 38), cx=.5, cy=.45)
A.alpha_composite(person)
bandy = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
SS = 4
tl = Image.new("RGBA", (W*SS, H*SS), (0, 0, 0, 0))
def gtxt(txt, size, cy, cx=385):
    f = ImageFont.truetype(FONT, size*SS); d = ImageDraw.Draw(tl)
    mk = Image.new("L", tl.size, 0); md = ImageDraw.Draw(mk)
    md.text((cx*SS, cy*SS), txt, font=f, fill=255, anchor="mm")
    gx = np.linspace(0, 1, tl.size[0])[None, :, None]
    col = (np.array((0, 235, 165))*(1-gx) + np.array((20, 190, 230))*gx).astype(np.uint8)
    col = np.broadcast_to(col, (tl.size[1], tl.size[0], 3)).copy()
    g = Image.fromarray(np.dstack([col, np.zeros(tl.size[::-1], np.uint8)]), "RGBA"); g.putalpha(mk); tl.alpha_composite(g)
gtxt("S T", 92, 232)
ImageDraw.Draw(tl).text((385*SS, 290*SS), "Sultan", font=ImageFont.truetype(FONT, 29*SS), fill=(255, 255, 255, 255), anchor="mm")
A.alpha_composite(tl.resize((W, H), Image.LANCZOS))
A.putalpha(circle_mask(512, 238))
A = with_ring(A)
save_set(A, "", (17, 10, 32))
A.save(f"{OUT}/logo-512.png")

# ===== Design B: separate badge design, teal glow + name plate across the bottom
B = radial_bg((16, 150, 140), (6, 28, 52), cx=.5, cy=.38)
pr = person.resize((int(512*.88),)*2, Image.LANCZOS)
B.alpha_composite(pr, ((512-pr.width)//2, 512-pr.height+10 - 8))
plate = Image.new("RGBA", (512, 512), (0, 0, 0, 0)); pd = ImageDraw.Draw(plate)
pd.rectangle([0, 392, 512, 512], fill=(6, 22, 44, 235))
pd.rectangle([0, 388, 512, 394], fill=(0, 224, 160, 255))
B.alpha_composite(plate)
text_center(B, "S T SULTAN", 32, 438, (255, 255, 255, 255), spacing=2)
B.putalpha(circle_mask(512, 238))
B = with_ring(B)
save_set(B, "alt-", (6, 22, 44))
print("ok")
